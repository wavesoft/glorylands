<table style="height: 100%; width:100%;">
<tr>
	<td valign="top" align="left">
	<div id="chat_content" style="padding: 2px; font-size: 12px; color: #333333; height:200px; overflow: auto;">GloryLands Chat Module</div>
	</td>
</tr>
<tr>
	<td height="20">
		<form onsubmit="chat_send(this.elements[0].value); this.elements[0].value=''; return false;">
		<input style="width: 100%" type="text" name="chat" />
		</form>
	</td>
</tr>
</table>
