<?php
return Array(
   "helpers" => false,
   "managers" => false,
   "lib" => array(),
   "default_outmode" => "json"
);
?>